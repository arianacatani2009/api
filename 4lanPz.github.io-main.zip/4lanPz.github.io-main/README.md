# Clase PokeAPI

## Se muestran Pokemon al momento de dar click a un botón
## Se muestra datos de personas con otra API de usuarios
![image](https://github.com/4lanPz/4lanPz.github.io/assets/117743495/fc999df6-625a-41c5-b26f-6ddeced07e48)
